# SPDX-License-Identifier: GPL-3.0-or-later
"""Road & sidewalk generator with road classification.

Classes: highway, single_lane, two_lane, four_lane, one_way.  The class
drives lane count/width, medians (painted / raised / planted), highway
barriers instead of sidewalks, and one-way arrow markings.  All variants
are real geometry — nothing is material-only.

Conventions: the road runs along +X centred on the origin; curvature bends
the centreline toward +Y.  1 unit = 1 metre.
"""

from __future__ import annotations

import math
from typing import Dict, List, Optional, Tuple

from ..core.params import GenerationParams
from ..core.randomization import make_rng
from ..utils.geometry import MeshBuilder

__all__ = ["build_asset"]

SEG_LEN = 3.0


def resolve_class(params: GenerationParams) -> Dict:
    """Normalise class-dependent road parameters."""
    p = params
    lane_w = max(2.5, min(5.0, p.lane_width or 3.5))
    lanes = max(1, int(p.lane_count or 2))
    info = {
        "lanes": lanes, "lane_w": lane_w,
        "median": bool(p.median_enabled), "median_w": max(0.4, p.median_width),
        "median_style": p.median_style or "raised",
        "sidewalk": bool(p.sidewalk_enabled), "sidewalk_w": p.sidewalk_width,
        "barrier_only": False, "one_way": p.road_direction != "two_way",
        "dir_sign": 1.0 if p.road_direction != "one_way_negative" else -1.0,
    }
    if p.road_class == "highway":
        info.update(lanes=max(4, lanes), lane_w=3.7, median=True,
                    sidewalk=False, barrier_only=True, crosswalks=False)
    elif p.road_class == "single_lane":
        info.update(lanes=1)
    elif p.road_class == "four_lane":
        info.update(lanes=4, median=True)
    elif p.road_class == "one_way":
        info.update(one_way=True, lanes=max(2, lanes))
    # carriageway width: honour an explicit road_width, else derive
    car_total = p.road_width if (p.road_width and p.road_width != 9.0) \
        else lanes * lane_w + 0.8
    if info["median"]:
        car_total += info["median_w"] + 0.4
    info["car_total"] = max(3.0, car_total)
    return info


def _centerline(segment_count: int, length: float, curvature_deg: float
                ) -> List[Tuple[float, float]]:
    n = max(2, int(segment_count))
    if curvature_deg <= 0.01:
        return [(-length / 2 + length * i / n, 0.0) for i in range(n + 1)]
    radius = length / math.radians(curvature_deg)
    pts: List[Tuple[float, float]] = []
    for i in range(n + 1):
        t = -length / 2 + length * i / n
        angle = t / radius
        pts.append((t, radius * (1.0 - math.cos(angle))))
    return pts


def _normal_of(p0, p1) -> Tuple[float, float]:
    dx, dy = p1[0] - p0[0], p1[1] - p0[1]
    ln = math.hypot(dx, dy) or 1.0
    return (-dy / ln, dx / ln)


def _profile(width: float, sidewalk: float, curb_h: float, grass: bool,
             median: Dict, class_info: Dict) -> Tuple[List, List[str]]:
    """Cross-section (offset, z) points centre→right→left + material per quad.

    Vertical faces (curbs, median walls, barriers) are two points sharing an
    offset, so every sweep quad is unique (validate-safe).
    """
    car_total = width
    car = car_total / 2
    csw = car + sidewalk if class_info["sidewalk"] else car + 0.4
    prof: List[Tuple[float, float]] = []

    if class_info["barrier_only"]:
        # highway: grass shoulder + concrete barrier instead of sidewalk
        prof += [(car + 2.0, -0.03), (car + 2.0, 0.02), (car + 0.5, 0.02),
                 (car + 0.5, curb_h + 0.28), (car + 0.2, curb_h + 0.30),
                 (car, curb_h - 0.01)]
    elif class_info["sidewalk"]:
        csw2 = car + sidewalk + 2.0
        if grass:
            prof += [(csw2, -0.03), (csw2, 0.02), (csw, 0.02)]
        prof += [(csw, curb_h), (car, curb_h), (car, curb_h - 0.01)]
    else:  # bare shoulders
        prof += [(car + 1.0, -0.03), (car + 1.0, 0.02), (car, 0.02),
                 (car, curb_h), (car, curb_h - 0.01)]

    if class_info["median"]:
        mw = class_info["median_w"] / 2
        rise = curb_h + 0.14 if class_info["median_style"] != "painted" \
            else curb_h + 0.005
        prof += [
            (mw, curb_h + 0.03),          # carriageway meets the median
            (mw, rise),                   # median curb (vertical, right)
            (-mw, rise),                  # median top
            (-mw, curb_h + 0.03),         # median curb (vertical, left)
        ]
    else:
        prof += [(0.0, curb_h + 0.03)]    # crown

    # mirrored tail (skip duplicating the centre point)
    tail: List[Tuple[float, float]] = []
    for (off, z) in reversed(prof):
        if off == 0.0:
            continue
        tail.append((-off, z))
    all_pts = prof + tail

    # material per quad
    n = len(all_pts)
    mats: List[str] = []
    med_mat = {"raised": "concrete", "planted": "grass",
               "painted": "asphalt"}.get(class_info["median_style"],
                                         "concrete")
    sidewalk = class_info["sidewalk_w"] if class_info["sidewalk"] else 0.0
    grass_on = class_info["sidewalk"] and sidewalk > 0
    for i in range(n - 1):
        o0, z0 = all_pts[i]
        o1, z1 = all_pts[i + 1]
        vertical = abs(o0 - o1) < 1e-6
        if vertical:
            mats.append("curb")
            continue
        am = (abs(o0) + abs(o1)) / 2
        if class_info["median"] and abs(am) < class_info["median_w"] / 2:
            mats.append(med_mat)
            continue
        if class_info["barrier_only"]:
            mats.append("asphalt" if am < car else "grass")
            continue
        if class_info["sidewalk"]:
            if am < car - 0.01:
                mats.append("asphalt")            # carriageway
            elif grass_on and am > car + sidewalk + 0.05:
                mats.append("grass")              # outer verge
            else:
                mats.append("sidewalk")
            continue
        mats.append("asphalt" if am < car + 0.01 else "grass")
    return all_pts, mats


def _emit(mb, prof_a, prof_b, base_a, base_b, normal, mats
          ) -> None:
    """Sweep two (offset, z) profiles between base_a and base_b."""
    if len(prof_a) != len(prof_b):
        return

    def world(base, off_z):
        return (base[0] + normal[0] * off_z[0],
                base[1] + normal[1] * off_z[0], off_z[1])

    for i in range(len(prof_a) - 1):
        pa0 = world(base_a, prof_a[i])
        pa1 = world(base_a, prof_a[i + 1])
        pb0 = world(base_b, prof_b[i])
        pb1 = world(base_b, prof_b[i + 1])
        vertical = abs(prof_a[i][0] - prof_a[i + 1][0]) < 1e-6
        if vertical:
            s = 1.0 if (prof_a[i][0] + prof_a[i + 1][0]) >= 0 else -1.0
            hint = (normal[0] * s, normal[1] * s, 0.0)
        else:
            hint = (0.0, 0.0, 1.0)
        mb.add_outward_face([pa0, pa1, pb1, pb0],
                            mats[i] if i < len(mats) else "asphalt", hint)


def _plate(mb, x0, y0, dx, dy, off, w, lnz, mat, z=0.165):
    nx, ny = -dy, dx
    pts = [
        (x0 + nx * off, y0 + ny * off, z),
        (x0 + nx * off + dy * w, y0 + ny * off - dx * w, z),
        (x0 + dx * lnz + nx * off + dy * w,
         y0 + dy * lnz + ny * off - dx * w, z),
        (x0 + dx * lnz + nx * off, y0 + dy * lnz + ny * off, z),
    ]
    mb.add_outward_face(pts, mat, (0, 0, 1))


def _arrow(mb, x, y, dx, dy, direction, z=0.166):
    """One-way direction arrow painted on the lane (shaft + head blades)."""
    s = direction
    _plate(mb, x, y, dx, dy, 0.0, 0.14, 1.4 * s, "road_marking", z=z)
    hx, hy = x + dx * 0.7 * s, y + dy * 0.7 * s
    for side in (-1, 1):
        nx, ny = -dy * side, dx * side
        mb.add_outward_face([
            (hx - dx * 0.7 * s + nx * 0.02, hy - dy * 0.7 * s + ny * 0.02, z),
            (hx - dx * 0.7 * s + nx * 0.34, hy - dy * 0.7 * s + ny * 0.34, z),
            (hx + dx * 0.55 * s, hy + dy * 0.55 * s, z),
            (hx + dx * 0.7 * s, hy + dy * 0.7 * s, z)],
            "road_marking", (0, 0, 1))


def _markings(mb, params: GenerationParams, centerline, class_info: Dict,
              median_on: bool) -> None:
    style = params.road_markings
    if style == "none":
        return
    car_total = class_info["car_total"]
    lanes = class_info["lanes"]
    lane_w = class_info["lane_w"]
    half = car_total / 2

    def sweep_lines():
        n = len(centerline) - 1
        return n

    if median_on and class_info["median_style"] == "painted":
        # double yellow center lines flanking the painted median
        for side in (-1, 1):
            i = 0
            while i < len(centerline) - 1:
                x0, y0 = centerline[i]
                x1, y1 = centerline[i + 1]
                seg = math.hypot(x1 - x0, y1 - y0) or 1.0
                dx, dy = (x1 - x0) / seg, (y1 - y0) / seg
                _plate(mb, x0, y0, dx, dy,
                       side * (class_info["median_w"] / 2 + 0.15), 0.10, seg,
                       "road_marking_yellow")
                i += 1

    if not class_info["one_way"] and lanes >= 2 and not median_on:
        # dashed centre line
        for i in range(len(centerline) - 1):
            x0, y0 = centerline[i]
            x1, y1 = centerline[i + 1]
            seg = math.hypot(x1 - x0, y1 - y0) or 1.0
            dx, dy = (x1 - x0) / seg, (y1 - y0) / seg
            if style == "simple":
                _plate(mb, x0, y0, dx, dy, 0.0, 0.10, seg, "road_marking")
                continue
            f = 0.0
            while f < seg:
                lnz = min(3.0, seg - f)
                _plate(mb, x0 + dx * f, y0 + dy * f, dx, dy, 0.0, 0.12, lnz,
                       "road_marking")
                f += 5.0

    if class_info["one_way"]:
        # lane dividers between same-direction lanes + direction arrows
        per_lane_line = [(lanes - 1 - k) * lane_w - half + lane_w
                         for k in range(lanes - 1)]
        for off in per_lane_line:
            for i in range(len(centerline) - 1):
                x0, y0 = centerline[i]
                x1, y1 = centerline[i + 1]
                seg = math.hypot(x1 - x0, y1 - y0) or 1.0
                dx, dy = (x1 - x0) / seg, (y1 - y0) / seg
                _plate(mb, x0, y0, dx, dy, off, 0.10, seg, "road_marking")
        road_len = (abs(centerline[0][0]) + abs(centerline[-1][0])) / 2
        # arrows every 12 m on each lane centre, kept inside the endpoints
        lane_centres = [half - (k + 0.5) * lane_w for k in range(lanes)]
        travelled = 0.0
        for i in range(len(centerline) - 1):
            x0, y0 = centerline[i]
            x1, y1 = centerline[i + 1]
            seg = math.hypot(x1 - x0, y1 - y0) or 1.0
            dx, dy = (x1 - x0) / seg, (y1 - y0) / seg
            f = 0.0
            while f < seg:
                if (travelled + f) % 12.0 < SEG_LEN \
                        and abs(x0 + dx * f) < road_len / 2 - 4.0:
                    for lc in lane_centres:
                        _arrow(mb, x0 + dx * f, y0 + dy * f, dx, dy,
                               class_info["dir_sign"])
                    f += 6.0
                else:
                    f += SEG_LEN
            travelled += seg

    # edge lines
    for side_mid in (-1, 1):
        for i in range(len(centerline) - 1):
            x0, y0 = centerline[i]
            x1, y1 = centerline[i + 1]
            seg = math.hypot(x1 - x0, y1 - y0) or 1.0
            dx, dy = (x1 - x0) / seg, (y1 - y0) / seg
            off = side_mid * (half - 0.18)
            _plate(mb, x0, y0, dx, dy, off, 0.10, seg, "road_marking")

    if params.crosswalks and not class_info.get("barrier_only"):
        for end in (0, len(centerline) - 1):
            cx_, cy_ = centerline[end]
            inward = 1.0 if end == 0 else -1.0
            walk_zone = car_total / 2 - 0.1
            for i in range(7):
                y = cy_ - walk_zone + (i + 0.5) * walk_zone * 2 / 7
                x0 = cx_
                x1 = cx_ + inward * 1.8
                mb.add_outward_face([
                    (x0, y - 0.22, 0.165), (x1, y - 0.22, 0.165),
                    (x1, y + 0.22, 0.165), (x0, y + 0.22, 0.165)],
                    "road_marking", (0, 0, 1))


def _build_sidewalk(mb, params: GenerationParams) -> None:
    """Sidewalk-only section without the carriageway."""
    length = params.road_length
    w = max(1.0, params.sidewalk_width)
    d = 0.14
    mb.add_box((0, 0, d / 2), (length, w, d), "sidewalk")
    mb.add_box((0, -w / 2 + 0.15, d / 2 + 0.02), (length, 0.3, d + 0.04),
               "curb")
    n_joints = max(1, int(length / 1.5))
    for i in range(n_joints):
        x = -length / 2 + (i + 0.5) * (length / n_joints)
        mb.add_plate((x, 0, d + 0.001), (0.02, w - 0.3, 0.002), "concrete",
                     (0, 0, 1))


def build_asset(params: GenerationParams) -> Tuple[MeshBuilder, Dict]:
    rng = make_rng(params.seed, "road")
    mb = MeshBuilder()
    if params.asset_type == "SIDEWALK":
        _build_sidewalk(mb, params)
        info = {
            "style": "sidewalk", "length": params.road_length,
            "faces": mb.face_count, "polys_estimated": mb.poly_count(),
        }
        return mb, info

    cls_info = resolve_class(params)
    length = params.road_length
    curb_h = max(0.05, min(0.35, params.curb_height))
    seg_count = max(4, int(length / SEG_LEN))
    profile, mats = _profile(
        cls_info["car_total"],
        params.sidewalk_width if cls_info["sidewalk"] else 0.0,
        curb_h, params.grass_strip, cls_info, cls_info)

    centerline = _centerline(seg_count, length, params.road_curvature)
    for i in range(len(centerline) - 1):
        p0, p1 = centerline[i], centerline[i + 1]
        nx, ny = _normal_of(p0, p1)
        _emit(mb, profile, profile, (p0[0], p0[1]), (p1[0], p1[1]),
              (nx, ny), mats)

    _markings(mb, params, centerline, cls_info, cls_info["median"])
    info = {
        "style": params.road_class, "length": length,
        "lanes": cls_info["lanes"], "median": cls_info["median"],
        "one_way": cls_info["one_way"],
        "faces": mb.face_count,
        "polys_estimated": mb.poly_count(),
    }
    return mb, info
