# SPDX-License-Identifier: GPL-3.0-or-later
"""Low-poly procedural character (NPC) generator.

Compact humanoid figures for city simulation: blocky-but-readable people with
varied builds, clothing styles and colours, hair, and optional accessories.

Design notes:
* Body proportions vary by seed (height, shoulder width, build); the
  "female"/"male" options bias build proportions without relying on
  stereotypes (they are subtle silhouette differences only).
* Clothing styles change silhouette + colours: casual (t-shirt & long
  pants), business (jacket & trousers), construction (hi-vis vest &
  helmet), pedestrian (coat).
* LOW/MEDIUM/HIGH detail controls segmentation and clothing layers.
* Ground origin at the feet; 1 unit = 1 metre; Y+ is the facing direction.
"""

from __future__ import annotations

import math
from typing import Dict, Tuple

from ..core.params import GenerationParams
from ..core.randomization import chance, make_rng, pick_weighted
from ..utils.geometry import MeshBuilder

__all__ = ["build_asset"]

_SKIN = [
    (0.86, 0.67, 0.55), (0.76, 0.57, 0.44), (0.62, 0.44, 0.32),
    (0.45, 0.31, 0.22), (0.30, 0.20, 0.14),
]
_HAIR = [
    (0.12, 0.08, 0.05), (0.30, 0.19, 0.10), (0.55, 0.42, 0.25),
    (0.85, 0.75, 0.55), (0.15, 0.15, 0.16), (0.55, 0.10, 0.05),
    (0.65, 0.65, 0.66),
]
_PALETTE_CASUAL = [(0.85, 0.35, 0.25), (0.25, 0.45, 0.70), (0.95, 0.85, 0.30),
                   (0.30, 0.62, 0.40), (0.90, 0.90, 0.92), (0.55, 0.30, 0.60),
                   (0.95, 0.55, 0.15)]
_PALETTE_BUSINESS = [(0.16, 0.18, 0.24), (0.30, 0.33, 0.40), (0.55, 0.56, 0.60),
                     (0.10, 0.12, 0.15), (0.42, 0.46, 0.52)]
_PALETTE_CONSTRUCTION = [(0.95, 0.55, 0.05), (0.85, 0.85, 0.10), (0.90, 0.90, 0.90)]
_PALETTE_PEDESTRIAN = [(0.45, 0.35, 0.28), (0.25, 0.28, 0.35), (0.60, 0.58, 0.52),
                       (0.20, 0.32, 0.28)]

_CLOTH_KEY = "painted_metal"   # matte painted family reads as fabric


def _hex(color) -> str:
    return "%02x%02x%02x" % tuple(int(max(0.0, min(1.0, c)) * 255)
                                  for c in color[:3])


def _cloth(params: GenerationParams, rng, role: str) -> str:
    styles = {
        "casual": _PALETTE_CASUAL, "business": _PALETTE_BUSINESS,
        "construction": _PALETTE_CONSTRUCTION,
        "pedestrian": _PALETTE_PEDESTRIAN,
    }
    style = params.npc_style
    if style == "random":
        style = pick_weighted(rng, [("casual", 4.0), ("business", 2.0),
                                    ("construction", 1.0),
                                    ("pedestrian", 3.0)])
    palette = styles.get(style, _PALETTE_CASUAL)
    return f"{_CLOTH_KEY}#{_hex(rng.choice(palette))}"


def build_asset(params: GenerationParams) -> Tuple[MeshBuilder, Dict]:
    rng = make_rng(params.seed, "npc")
    mb = MeshBuilder()
    seg = {"low": 6, "medium": 8, "high": 10}.get(params.detail_level, 8)

    h = max(1.2, params.npc_height * rng.uniform(0.94, 1.06))
    gender = params.npc_gender
    if gender == "random":
        gender = "female" if rng.random() < 0.5 else "male"
    # subtle build variation (no stereotypes, just silhouette variety)
    build_w = rng.uniform(0.92, 1.10)
    if gender == "female":
        shoulder = 0.30 * build_w
        hip = 0.34 * build_w
    else:
        shoulder = 0.36 * build_w
        hip = 0.30 * build_w

    style = params.npc_style
    if style == "random":
        style = pick_weighted(rng, [("casual", 4.0), ("business", 2.0),
                                    ("construction", 1.0),
                                    ("pedestrian", 3.0)])

    skin = f"painted_metal#{_hex(rng.choice(_SKIN))}"
    hair_c = f"painted_metal#{_hex(rng.choice(_HAIR))}"
    shirt = _cloth(params, rng, "shirt")
    pants = _cloth(params, rng, "pants")
    shoes = f"painted_metal#{_hex((0.12, 0.11, 0.11))}"

    # proportions (fractions of height)
    leg_h = h * 0.46
    torso_h = h * 0.30
    head_h = h * 0.13
    neck_z = leg_h + torso_h

    # legs
    leg_w = 0.09 * build_w
    for s in (-1, 1):
        mb.add_box((s * hip * 0.55, 0, leg_h / 2), (leg_w, leg_w, leg_h),
                   pants)
        mb.add_box((s * hip * 0.55, 0.01, 0.045), (leg_w * 1.15, 0.22,
                   0.09), shoes)
    # torso: tapered via two stacked boxes (chest + hips)
    mb.add_box((0, 0, leg_h + torso_h * 0.28), (hip * 2.05, 0.19, torso_h
               * 0.56), shirt)
    mb.add_box((0, 0, leg_h + torso_h * 0.74), (shoulder * 2.05, 0.21,
               torso_h * 0.52), shirt)
    if style == "business" and params.detail_level != "low":
        # jacket lapel strip
        mb.add_box((0, -0.115, leg_h + torso_h * 0.62), (0.03, 0.015,
                   torso_h * 0.7), f"painted_metal#{_hex((0.08, 0.08, 0.10))}")
    if style == "construction":
        # hi-vis vest over torso
        mb.add_box((0, 0, leg_h + torso_h * 0.55), (shoulder * 2.2, 0.24,
                   torso_h * 0.6), f"painted_metal#{_hex((0.95, 0.5, 0.05))}")
    # arms
    arm_w = 0.075 * build_w
    arm_len = torso_h * 1.15
    for s in (-1, 1):
        mb.add_box((s * (shoulder + arm_w / 2), 0, leg_h + torso_h
                    - arm_len / 2 + 0.02), (arm_w, arm_w, arm_len), shirt)
        mb.add_box((s * (shoulder + arm_w / 2), 0, leg_h + torso_h
                    - arm_len + 0.02), (arm_w * 1.1, arm_w * 1.1, 0.08),
                   skin)
    # head + neck
    mb.add_box((0, 0, neck_z + 0.03), (0.07, 0.07, 0.06), skin)
    head_r = head_h * 0.42
    mb.add_sphere((0, 0, neck_z + head_h * 0.62), head_r, seg, seg // 2,
                  skin)
    # hair cap (short/long)
    hair_len = rng.uniform(0.35, 0.75)
    mb.add_sphere((0, 0, neck_z + head_h * 0.62 + head_r * 0.32), head_r
                  * 1.04, seg, seg // 2, hair_c, squash=hair_len)
    if hair_len > 0.55:
        mb.add_box((0, head_r * 0.75, neck_z + head_h * 0.35), (head_r
                   * 1.5, 0.08, head_r * hair_len * 1.4), hair_c)

    # accessories
    if params.npc_accessories:
        if chance(rng, 0.35):
            # backpack / handbag
            mb.add_box((0, 0.16, leg_h + torso_h * 0.6), (shoulder * 1.4,
                       0.10, torso_h * 0.8),
                       f"painted_metal#{_hex(rng.choice(_PALETTE_CASUAL))}")
        if style == "construction":
            # helmet
            mb.add_sphere((0, 0, neck_z + head_h * 0.95), head_r * 1.25,
                          seg, seg // 2,
                          f"painted_metal#{_hex((0.95, 0.55, 0.05))}",
                          squash=0.6)
        elif chance(rng, 0.25):
            # cap
            mb.add_sphere((0, 0, neck_z + head_h * 1.0), head_r * 1.15,
                          seg, seg // 2,
                          f"painted_metal#{_hex(rng.choice(_PALETTE_CASUAL))}",
                          squash=0.45)
        if style == "business" and chance(rng, 0.3):
            # briefcase
            mb.add_box((shoulder + arm_w / 2 + 0.05, 0, leg_h * 0.72),
                       (0.22, 0.06, 0.28),
                       f"painted_metal#{_hex((0.12, 0.10, 0.09))}")

    info = {
        "style": style,
        "build": gender,
        "faces": mb.face_count,
        "polys_estimated": mb.poly_count(),
    }
    return mb, info
