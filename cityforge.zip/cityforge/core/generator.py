# SPDX-License-Identifier: GPL-3.0-or-later
"""Generation dispatcher: turns validated parameters into Blender objects.

Handles type routing (building / road / vegetation / prop / vehicle), polygon
budget fallback and asset-manager integration.
"""

from __future__ import annotations

from typing import Optional

import bpy

from ..core.params import (
    BUILDING_TYPES,
    GenerationParams,
    PROP_TYPES,
    ROAD_TYPES,
    TYPE_DEFAULT_STYLE,
    VEGETATION_TYPES,
)
from ..utils import get_logger
from ..utils.naming import asset_name
from . import asset_manager
from .materials import apply_variation

_log = get_logger()

__all__ = ["generate_asset", "regenerate_asset"]


def generate_asset(params: GenerationParams) -> Optional[bpy.types.Object]:
    """Generate one asset and link it into the CityForge collection tree.

    Returns the created object, or None on failure (after logging).
    """
    params = _prepare(params)

    keep_normals_engine = bpy.context.scene.render.engine

    if params.asset_type in BUILDING_TYPES:
        from ..generators import buildings
        mb, info = buildings.build_building(params)
        mesh, _mats = mb.finish("CFBuilding")
    elif params.asset_type in ROAD_TYPES:
        from ..generators import roads
        mb, info = roads.build_asset(params)
        mesh, _mats = mb.finish("CFRoad")
    elif params.asset_type in VEGETATION_TYPES:
        from ..generators import vegetation
        mb, info = vegetation.build_asset(params)
        mesh, _mats = mb.finish("CFTree")
    elif params.asset_type in PROP_TYPES:
        from ..generators import props
        mb, info = props.build_asset(params)
        mesh, _mats = mb.finish("CFProp")
    elif params.asset_type == "VEHICLE":
        from ..generators import vehicles
        mb, info = vehicles.build_asset(params)
        mesh, _mats = mb.finish("CFVehicle")
    elif params.asset_type == "NPC":
        from ..generators import characters
        mb, info = characters.build_asset(params)
        mesh, _mats = mb.finish("CFCharacter")
    elif params.asset_type == "PARK":
        from ..generators import parks
        mb, info = parks.build_asset(params)
        mesh, _mats = mb.finish("CFPark")
    else:
        _log.error("asset type %s has no generator", params.asset_type)
        return None

    poly_count = mb.poly_count()

    # polygon budget: progressively fall back to cheaper construction rather
    # than shipping an unbudgeted mesh
    if poly_count > params.poly_budget and params.detail_level != "low":
        cheaper = {"high": "medium", "medium": "low"}.get(params.detail_level)
        _log.info("poly budget exceeded (%d > %d); regenerating at %s detail",
                  poly_count, params.poly_budget, cheaper)
        params.detail_level = cheaper
        return generate_asset(params)
    if poly_count > params.poly_budget and params.detail_level == "low" \
            and not params.extra.get("_tier2_done"):
        # second fallback tier: denser window spacing, no balconies
        params.extra["_tier2_done"] = True
        params.window_spacing = max(3.0, params.window_spacing * 1.8)
        params.balcony_style = "none"
        params.roof_extras = 0
        params.podium_floors = 0
        _log.info("tier-2 budget fallback: reduced detail levels")
        obj = generate_asset(params)
        if obj is not None:
            obj["cityforge_budget_warning"] = True
        return obj
    if poly_count > params.poly_budget:
        _log.warning("asset exceeds poly budget even at low detail "
                     "(%d > %d)", poly_count, params.poly_budget)

    name = asset_name(params.asset_type, info.get("style",
                      params.asset_type.lower()), params.seed)
    obj = asset_manager.create_asset(name, mesh, params, poly_count)
    apply_variation(obj, params.seed)
    obj["cityforge_info"] = {
        k: (v if isinstance(v, (int, float, str)) else str(v))
        for k, v in info.items()}
    # parks instantiate their vegetation/props as parented children
    if params.asset_type == "PARK" and info.get("park_children"):
        from ..generators import parks
        parks.build_children(params, info["park_children"], obj)
        obj["cityforge_park_children"] = len(obj.children)
    # commercial buildings get readable sign text (joined into the mesh)
    if params.asset_type in BUILDING_TYPES and info.get("business_name"):
        from ..generators import buildings as buildings_mod
        buildings_mod.apply_signage_text(obj, params, info)
        poly_count = len(obj.data.polygons)
        obj["cityforge_polygons"] = poly_count
    # vehicle scale applies at object level so meshes stay shared
    if params.asset_type == "VEHICLE" and info.get("scale"):
        s = float(info["scale"])
        if abs(s - 1.0) > 1e-3:
            obj.scale = (s, s, s)
    return obj

def _prepare(params: GenerationParams) -> GenerationParams:
    """Fill implicit defaults implied by the asset type (style etc.)."""
    if params.asset_type in BUILDING_TYPES:
        if params.style == "auto" or not params.style:
            params.style = TYPE_DEFAULT_STYLE.get(
                params.asset_type, "modern_residential")
        # NOTE: style-typical defaults are applied by the UI (style_update)
        # and by params.apply_style_defaults() for script paths; we do NOT
        # re-apply here so user overrides survive.
        # Architectural-level normalization is always safe (additive).
        from .params import apply_arch_levels
        apply_arch_levels(params)
    return params


def regenerate_asset(obj: bpy.types.Object) -> Optional[bpy.types.Object]:
    """Rebuild a previously generated object from its stored parameters."""
    old_params = asset_manager.get_stored_params(obj)
    if old_params is None:
        _log.error("%s was not generated by CityForge", obj.name)
        return None
    new_obj = generate_asset(old_params)
    if new_obj is not None:
        asset_manager.delete_asset(obj)
    return new_obj
